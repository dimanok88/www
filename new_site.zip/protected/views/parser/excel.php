<h2>Экспорт прайса</h2>

<? $this->renderPartial('_filterParser');?>
