<?
$this->menu = array(
        array('label' => 'Добавить категорию', 'url' => array('category/addCategory', 'type'=>$type)),
        //array('label' => 'Список предметов', 'url' => array('item/modelListItem', 'id'=>$idModel)),
    );
?>
 
