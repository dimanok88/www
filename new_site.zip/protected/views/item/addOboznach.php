<?= $this->renderPartial('_formOboz', array('model'=>$model, 'type'=>$type)); ?>
 
