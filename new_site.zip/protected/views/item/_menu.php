<?
$this->menu = array(
        array('label' => 'Обозначения', 'url' => array('item/oboznach', 'type'=>Yii::app()->controller->action->id)),
        array('label' => 'Раздел категорий', 'url' => array('item/category', 'type'=>Yii::app()->controller->action->id)),
        array('label' => 'Проценты', 'url' => array('percent/index', 'type'=>Yii::app()->controller->action->id)),
        array('label' => 'Типы', 'url' => array('typeItem/index', 'type'=>Yii::app()->controller->action->id)),
    );
?>
 
