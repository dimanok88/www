<?
$this->menu = array(
        array('label' => 'Добавить обозначение', 'url' => array('item/addOboznach', 'type'=>$type)),
        //array('label' => 'Раздел категорий', 'url' => array('item/category', 'type'=>Yii::app()->controller->action->id)),
    );
?>
 
